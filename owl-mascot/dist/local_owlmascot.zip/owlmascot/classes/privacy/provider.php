<?php
// This file is part of Moodle - http://moodle.org/

namespace local_owlmascot\privacy;

/**
 * The plugin keeps no user data: the like counter lives only in the open page.
 */
class provider implements \core_privacy\local\metadata\null_provider {
    public static function get_reason(): string {
        return 'privacy:metadata';
    }
}
